#ifndef ALL_STRUCTS_C_H
#define ALL_STRUCTS_C_H


class All_structs.c
{
    public:
        All_structs.c();
        virtual ~All_structs.c();

    protected:

    private:
};

#endif // ALL_STRUCTS_C_H
